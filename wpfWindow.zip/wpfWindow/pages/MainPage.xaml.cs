using System.Windows.Controls;

namespace wpfWindow.pages;

public partial class MainPage : Page
{
    public MainPage()
    {
        InitializeComponent();
    }
}

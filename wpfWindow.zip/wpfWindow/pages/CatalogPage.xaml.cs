using System.Windows;
using System.Windows.Controls;
using wpfWindow.windows;

namespace wpfWindow.pages;

public partial class CatalogPage : Page
{
    public CatalogPage()
    {
        InitializeComponent();

        foreach (Book book in GetStartingBooks())
            dataBooks.Items.Add(book);
    }

    private static IEnumerable<Book> GetStartingBooks()
    {
        yield return new Book { Title = "Мастер и Маргарита", Author = "М. Булгаков", Year = 1967 };
        yield return new Book { Title = "Три товарища", Author = "Э.М. Ремарк", Year = 1936 };
        yield return new Book { Title = "Пикник на обочине", Author = "Стругацкие", Year = 1972 };
    }

    private void Add_Click(object sender, RoutedEventArgs e)
    {
        var b = new Book();
        var w = new AddBookWindow { DataContext = b };

        if (w.ShowDialog() == true)
            dataBooks.Items.Add(b);
    }

    private void Del_Click(object sender, RoutedEventArgs e)
    {
        // Удаление пока не реализовано (как и в исходном проекте)
    }
}

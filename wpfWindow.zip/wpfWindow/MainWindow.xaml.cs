using System.Windows;
using wpfWindow.pages;

namespace wpfWindow;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
        MainFrame.Navigate(new MainPage());
    }

    private void ShowMain_Click(object sender, RoutedEventArgs e) => MainFrame.Navigate(new MainPage());

    private void ShowCatalog_Click(object sender, RoutedEventArgs e) => MainFrame.Navigate(new CatalogPage());

    private void ShowDesc_Click(object sender, RoutedEventArgs e) => MainFrame.Navigate(new DescPage());

    private void Forward_Click(object sender, RoutedEventArgs e)
    {
        if (MainFrame.CanGoForward)
            MainFrame.GoForward();
    }

    private void Back_Click(object sender, RoutedEventArgs e)
    {
        if (MainFrame.CanGoBack)
            MainFrame.GoBack();
    }
}

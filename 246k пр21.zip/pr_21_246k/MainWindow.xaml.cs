using System.Windows;

namespace pr_21_246k;

public partial class MainWindow : Window
{
    private readonly List<Product> products = new()
    {
        new Product { Name = "Товар 1", Count = 5,  Price = 150  },
        new Product { Name = "Товар 2", Count = 54, Price = 2150 },
        new Product { Name = "Товар 3", Count = 55, Price = 5150 },
        new Product { Name = "Товар 4", Count = 75, Price = 850  },
    };

    public MainWindow()
    {
        InitializeComponent();
        tableProduct.ItemsSource = products;
    }
}

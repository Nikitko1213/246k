namespace pr_21_246k;

public class Product
{
    public string Name { get; set; } = string.Empty;
    public int Price { get; set; }
    public int Count { get; set; }
}

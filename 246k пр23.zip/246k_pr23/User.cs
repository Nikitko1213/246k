using System.ComponentModel;

namespace _246k_pr23;

public class User : IDataErrorInfo
{
    public string Name { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public int Age { get; set; }

    public string? Error => null;

    public string? this[string columnName] => columnName switch
    {
        nameof(Name)  => ValidateName(),
        nameof(Age)   => ValidateAge(),
        nameof(Email) => ValidateEmail(),
        _             => null
    };

    private string? ValidateName() =>
        string.IsNullOrWhiteSpace(Name) ? "Имя не может быть пустым" : null;

    private string? ValidateAge() =>
        Age < 0 || Age > 120 ? "Возраст должен быть от 0 до 120" : null;

    private string? ValidateEmail()
    {
        if (string.IsNullOrWhiteSpace(Email))
            return "Email не может быть пустым";

        int in_at = Email.IndexOf('@');
        int in_point = Email.IndexOf('.');

        if (in_at == -1 || in_point == -1 || in_point < in_at)
            return "Email некорректен";

        return null;
    }
}

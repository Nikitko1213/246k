using System.Windows;

namespace _246k_pr23;

public partial class MainWindow : Window
{
    private readonly User person = new();

    public MainWindow()
    {
        InitializeComponent();
        DataContext = person;
    }

    private void Reg_Click(object sender, RoutedEventArgs e)
    {
        MessageBox.Show($"Зарегистрирован: \n{person.Name}\n{person.Email}\n{person.Age} лет");
    }
}

using System.Windows;

namespace _246k_pr23;

public partial class App : Application
{
}

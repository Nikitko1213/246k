namespace _246k_json;

public class Student
{
    public string Name { get; set; } = string.Empty;
    public int Age { get; set; }
}

using System.Collections.ObjectModel;
using System.IO;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.Unicode;
using System.Windows;

namespace _246k_json;

public partial class MainWindow : Window
{
    private const string FileName = "students.json";

    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true,
        Encoder = JavaScriptEncoder.Create(UnicodeRanges.All)
    };

    private ObservableCollection<Student> students = new();

    public MainWindow()
    {
        InitializeComponent();
        tableStudent.ItemsSource = students;
    }

    private void Save_Click(object sender, RoutedEventArgs e)
    {
        File.WriteAllText(FileName, JsonSerializer.Serialize(students, JsonOptions));
        MessageBox.Show("Данные сохранены!");
    }

    private void Load_Click(object sender, RoutedEventArgs e)
    {
        string json = File.ReadAllText(FileName);

        students = JsonSerializer.Deserialize<ObservableCollection<Student>>(json)
                   ?? new ObservableCollection<Student>();
        tableStudent.ItemsSource = students;
    }
}
